package Proyecto_1;

public class Mascota {

	private int idMascota;
	private String nombre;
	private int cantidadDePatas;
	
	public int getIdMascota() {
		return idMascota;
	}
	public void setIdMascota(int idMascota) {
		this.idMascota = idMascota;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getCantidadDePatas() {
		return cantidadDePatas;
	}
	public void setCantidadDePatas(int cantidadDePatas) {
		this.cantidadDePatas = cantidadDePatas;
	}
	Mascota (int idMascota, String nombre, int cantidadDePatas) {
		this.idMascota = idMascota;
		this.nombre = nombre;
		this.cantidadDePatas = cantidadDePatas;
	}
	public String mostrarMascota() {
		return idMascota + " - " + nombre + " - " + cantidadDePatas;
		
	}

}
