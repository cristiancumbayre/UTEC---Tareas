package Proyecto_1;

import java.io.PrintStream;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;

public class ManejarMascotas {

	public static void main(String[] args) throws PatasExcepcion{
		String[] mascotas = new String[3];
		int contadorMascotas=0;

		while(contadorMascotas<mascotas.length) {

				Scanner leer = new Scanner (System.in);
				System.out.println("Ingrese el id de la mascota: ");
				int idMascotas = leer.nextInt();
				System.out.println("Ingrese el nombre de la mascota: ");
				String nombre = leer.next();

				try {
					int cantidadDePatas=leerPatas();
					System.out.println("La mascota ha sido ingresada correctamente");
					contadorMascotas=contadorMascotas+1;
					System.out.println(contadorMascotas);
					Mascota oMascotas = new Mascota(idMascotas, nombre, cantidadDePatas);

				}catch(PatasExcepcion e){
					System.out.println(e);
					System.out.println(contadorMascotas);
				}
			}System.out.println(contadorMascotas);
			System.out.println(Arrays.asList(mascotas));
			System.out.println("Prueba comit");
		}
	

	private static int leerPatas() throws PatasExcepcion{
		Scanner cantidadPatas = new Scanner (System.in);
		System.out.println("Ingrese el número de patas de la mascota: ");
		int cantidadDePatas = cantidadPatas.nextInt();
		if (cantidadDePatas != 2 && cantidadDePatas != 4) {
			throw new PatasExcepcion(null);
		}
		return cantidadDePatas;
	}
}

