package Proyecto_1;

import java.util.Scanner;
import java.util.Arrays;
import java.util.InputMismatchException;

public class Numeros_enteros {

	public static void main(String[] args) {
		int[] numeros = new int[5];
		int validos=0;
		int invalidos=0;
		int suma=0;
		
			for(int i=0; i<numeros.length; i++) {
			
				Scanner leer = new Scanner(System.in);
				int num;
				try {
					System.out.println("Ingrese un número: ");
					num=leer.nextInt();		
					numeros[i]=num;
					validos++;
					suma+=numeros[i];
				}catch(InputMismatchException e){
					System.out.println("Debe ingresasr solo números");
					numeros[i]=0;
					invalidos++;
				}
				
			
		}System.out.println(Arrays.toString(numeros));
		System.out.println("La cantidad de datos válidos es: " + validos);
		System.out.println("La cantidad de datos inválidos es: " + invalidos);
		System.out.println("La suma de datos válidos es: " + suma);

	}

}
