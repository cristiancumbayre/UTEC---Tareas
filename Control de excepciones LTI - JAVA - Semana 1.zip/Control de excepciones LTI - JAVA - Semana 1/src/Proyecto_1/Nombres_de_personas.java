package Proyecto_1;

import java.util.Scanner;

public class Nombres_de_personas {

	public static void main(String[] args) {
		
		String[] personas = {"Elisa", "Esteban", "Florencia", "Sebastián", "Paula"};
		
		Scanner sc=new Scanner(System.in);
		int numA;
		System.out.println("Ingrese número: ");
		numA=sc.nextInt();
		
		//System.out.println(personas [numA]);
		
		try {
			System.out.println(personas [numA]);
		}
		catch (ArrayIndexOutOfBoundsException e){
			System.out.println("El número está fuera del rango");
			System.out.println("El indice de objetos del array va de: 0 a " + (personas.length-1));
		}


	}

}
