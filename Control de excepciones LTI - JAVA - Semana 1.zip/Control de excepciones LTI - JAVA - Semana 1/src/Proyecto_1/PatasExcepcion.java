package Proyecto_1;

public class PatasExcepcion extends Exception{
	public PatasExcepcion (String msg) {
		super("La cantidad de patas no es válida");
	}
}
